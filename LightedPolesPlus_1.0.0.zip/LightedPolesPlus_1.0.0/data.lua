require("prototypes.entity")
require("prototypes.item")