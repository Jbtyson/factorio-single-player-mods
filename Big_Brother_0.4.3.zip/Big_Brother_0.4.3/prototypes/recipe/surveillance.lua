data:extend(
{
    {
        type = "recipe",
        name = "big_brother-surveillance-center",
        enabled = false,
        ingredients =
        {
            {"radar", 5},
            {"processing-unit", 5},
            {"steel-plate", 40},
            {"copper-cable", 40}
        },
        result = "big_brother-surveillance-center"
    }
})
