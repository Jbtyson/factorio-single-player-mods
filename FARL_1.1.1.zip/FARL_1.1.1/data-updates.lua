table.insert(data.raw["technology"]["rail-signals"].effects,
    {
        type="unlock-recipe",
        recipe = "farl"
    })
table.insert(data.raw["technology"]["rail-signals"].effects,
    {
        type="unlock-recipe",
        recipe = "farl-roboport"
    })
