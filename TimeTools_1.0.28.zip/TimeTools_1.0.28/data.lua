require("utils")
require("config")
require("prototypes.styles")
require("prototypes.signals")
require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipies")

