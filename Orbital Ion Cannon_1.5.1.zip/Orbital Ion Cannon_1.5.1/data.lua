require("prototypes.items")
require("prototypes.entities")
require("prototypes.recipes")
require("prototypes.technologies")
require("prototypes.announcers")
require("prototypes.styles")

data:extend({
  {
    type = "custom-input",
    name = "ion-cannon-hotkey",
    key_sequence = "I",
    consuming = "script-only"
  }
})
